package ensaac.ma.carparkingsystem;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.HashMap;

public class ParkingAdapter extends BaseAdapter {
    private Context context;
    private HashMap<String, Boolean> parkingStatus; // Key: Spot ID (e.g., "E-25"), Value: Occupied (true/false)

    public ParkingAdapter(Context context, HashMap<String, Boolean> parkingStatus) {
        this.context = context;
        this.parkingStatus = parkingStatus;
    }

    @Override
    public int getCount() {
        return parkingStatus.size();
    }

    @Override
    public Object getItem(int position) {
        return parkingStatus.keySet().toArray()[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_1, parent, false);
        }

        TextView spotTextView = convertView.findViewById(android.R.id.text1);
        String spotId = (String) getItem(position);
        boolean isOccupied = parkingStatus.get(spotId);

        spotTextView.setText(spotId);
        spotTextView.setTextColor(Color.WHITE);
        spotTextView.setBackgroundColor(isOccupied ? Color.RED : Color.GREEN);
        spotTextView.setTextSize(16);
        spotTextView.setPadding(16, 16, 16, 16);

        return convertView;
    }
}