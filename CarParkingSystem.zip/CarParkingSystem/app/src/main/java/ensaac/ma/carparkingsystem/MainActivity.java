package ensaac.ma.carparkingsystem;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up button click listeners
        Button buttonLevelA = findViewById(R.id.buttonLevelA);
        Button buttonLevelB = findViewById(R.id.buttonLevelB);
        Button buttonLevelC = findViewById(R.id.buttonLevelC);
        Button buttonLevelD = findViewById(R.id.buttonLevelD);

        buttonLevelA.setOnClickListener(v -> loadFragment(new ParkingALevelFragment()));
        buttonLevelB.setOnClickListener(v -> loadFragment(new ParkingBLevelFragment()));
        buttonLevelC.setOnClickListener(v -> loadFragment(new ParkingCLevelFragment()));
        buttonLevelD.setOnClickListener(v -> loadFragment(new ParkingDLevelFragment()));

        // Load the default fragment (Level A)
        loadFragment(new ParkingALevelFragment());
    }

    private void loadFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.fragmentContainer, fragment);
        transaction.commit();
    }
}