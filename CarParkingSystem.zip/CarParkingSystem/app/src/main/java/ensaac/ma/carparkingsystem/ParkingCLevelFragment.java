package ensaac.ma.carparkingsystem;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import androidx.fragment.app.Fragment;
import java.util.HashMap;

public class ParkingCLevelFragment extends Fragment {
    private GridView parkingGrid;
    private ParkingAdapter parkingAdapter;
    private HashMap<String, Boolean> parkingStatus;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_parking_c_level, container, false);

        parkingGrid = view.findViewById(R.id.parkingGrid);

        // Initialize parking status (example data)
        parkingStatus = new HashMap<>();
        parkingStatus.put("C-1", false);
        parkingStatus.put("C-2", false);
        parkingStatus.put("C-3", false);
        parkingStatus.put("C-4", false);
        parkingStatus.put("C-5", true);
        parkingStatus.put("C-6", false);
        parkingStatus.put("C-7", false);
        parkingStatus.put("C-8", false);
        parkingStatus.put("C-9", false);
        parkingStatus.put("C-10", false);

        // Set up the adapter
        parkingAdapter = new ParkingAdapter(getActivity(), parkingStatus);
        parkingGrid.setAdapter(parkingAdapter);

        // Simulate real-time updates
        simulateRealTimeUpdates();

        return view;
    }

    private void simulateRealTimeUpdates() {
        Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Randomly update the status of each parking spot
                for (String spotId : parkingStatus.keySet()) {
                    boolean isOccupied = Math.random() < 0.5; // 50% chance of being occupied
                    parkingStatus.put(spotId, isOccupied);
                }

                // Notify the adapter of data changes
                parkingAdapter.notifyDataSetChanged();

                // Repeat the simulation every 5 seconds
                handler.postDelayed(this, 5000);
            }
        }, 5000);
    }
}